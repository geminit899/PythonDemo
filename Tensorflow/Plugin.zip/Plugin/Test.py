import tensorflow as tf
import os
import sys
from tensorflow.examples.tutorials.mnist import input_data
import importlib
mnist = input_data.read_data_sets("MNIST_data/", one_hot=True)


def get_batch(batch, epoch, batch_size):
    batch_x = []
    batch_y = []
    length = len(batch[0])
    start_index = (epoch - 1) * batch_size % length
    for i in range(batch_size):
        index = (start_index + i) % length
        batch_x.append(batch[0][index])
        batch_y.append(batch[1][index])
    return batch_x, batch_y

if __name__ == '__main__':
    super_param = {
        'epochs': "100",
        'batchSize': '128',
        'dropout': '0.85',
        'learning_rate': '0.01'
    }
    tmp_summary = "/Users/geminit/PycharmProjects/PythonDemo/Tensorflow/Plugin/summary"
    tmp_result = "/Users/geminit/PycharmProjects/PythonDemo/Tensorflow/Plugin/results"


    x = tf.placeholder(tf.float32)
    y = tf.placeholder(tf.float32)
    keep_prob = tf.placeholder(tf.float32)

    sys.path.append("/Users/geminit/PycharmProjects/PythonDemo/Tensorflow/Plugin/")
    module = importlib.import_module("TrainImpl")
    TrainImpl = getattr(module, "TrainImpl")
    train = TrainImpl(x, y, keep_prob, super_param)
    train.variables()
    optF = train.modal()
    lossF = train.loss()
    accF = train.accuracy()

    transformed_data = train.transform(None, None, None)
    with tf.device(''):
        session = tf.InteractiveSession()
        session.run(tf.initialize_all_variables())

        saver = tf.train.Saver()

        tf.summary.scalar('loss', lossF)
        tf.summary.scalar('accuracy', accF)
        merged_summary_op = tf.summary.merge_all()
        summary_writer = tf.summary.FileWriter(tmp_summary, graph=tf.get_default_graph())

        compare = {
            'loss': 0,
            'accuracy': 0
        }
        for i in range(1, int(super_param['epochs']) + 1):
            batch_x, batch_y = get_batch(transformed_data, i, int(super_param['batchSize']))
            session.run([optF],
                        feed_dict={x: batch_x, y: batch_y, keep_prob: float(super_param['dropout'])})
            if i % 10 == 0:
                _, loss, acc, summ = session.run([optF, lossF, accF, merged_summary_op],
                                                 feed_dict={x: batch_x, y: batch_y, keep_prob: 1})
                print("loss: " + str(loss) +  ", acc: " + str(acc))
                summary_writer.add_summary(summ, i)
                compare['loss'] = loss
                compare['accuracy'] = acc

        summary_writer.close()

        saver.save(session, os.path.join(tmp_result, 'result'), global_step=int(super_param['epochs']))
